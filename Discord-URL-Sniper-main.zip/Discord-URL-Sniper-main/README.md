- Discord-URL-Sniper

- const berkListenerToken = "";
- const berkToken = "";
- const berkServerid = "";
- const berkKanalid = "";

buraları kendine göre değiştir

cmd açıp node index.js yaz çalıştır

Kuramıyorsanız dc : rateberk & nolyrica0
